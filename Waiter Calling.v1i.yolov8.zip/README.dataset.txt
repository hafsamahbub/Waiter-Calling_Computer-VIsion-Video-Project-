# Waiter Calling > 2025-07-04 2:53pm
https://universe.roboflow.com/skin-condition-detection/waiter-calling

Provided by a Roboflow user
License: CC BY 4.0

